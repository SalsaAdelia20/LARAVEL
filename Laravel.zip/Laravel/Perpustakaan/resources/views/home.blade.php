<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewpost" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" href="js/script.js">
    <title>Salsa Adelia | Home</title>
</head>
<body>
    <h1>Halaman Home</h1>
</body>
</html>